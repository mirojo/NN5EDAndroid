package com.hrupin.sample.sms;

import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

public class SmsBroadcastReceiver extends BroadcastReceiver {

    private static final String TAG = SmsBroadcastReceiver.class.getSimpleName();


    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i(TAG, "Intent recieved: " + intent.getAction());
        Toast.makeText(context, "SMS RECEIVED:", Toast.LENGTH_LONG).show();

        if(intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")){
            Log.i(TAG, "l> SMS Recibido");
            //---get the SMS message passed in---
            Bundle bundle = intent.getExtras();
            SmsMessage[] msgs = null;
            String msg_from;
            if (bundle != null){
                //---retrieve the SMS message received---
                try{
                    Object[] pdus = (Object[]) bundle.get("pdus");
                    msgs = new SmsMessage[pdus.length];
                    for(int i=0; i<msgs.length; i++){
                        msgs[i] = SmsMessage.createFromPdu((byte[])pdus[i]);
                        msg_from = msgs[i].getOriginatingAddress();
                        String msgBody = msgs[i].getMessageBody();
                        Log.i(TAG, "l> mensaje: " + msgBody);
                        Log.i(TAG, "l> msg_from: " + msg_from);
                        if(msgBody.toLowerCase().contains("hola")){
                            abortBroadcast();
                            Log.i(TAG, "l> abortBroadcast.");
                        }
                    }
                }catch(Exception e){
                    Log.i(TAG, "l> Exception caught" + e.getMessage());
                }
            }
        }else{
            Log.i(TAG, "l> NO android.provider.Telephony.SMS_RECEIVED");
        }

    }
}
