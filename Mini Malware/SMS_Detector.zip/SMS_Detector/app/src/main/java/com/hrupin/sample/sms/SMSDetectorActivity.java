package com.hrupin.sample.sms;

import android.app.Activity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.widget.TextView;

public class SMSDetectorActivity extends Activity {

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        SmsManager sm = SmsManager.getDefault();
        // here is where the destination of the text should go

        String number = "5556";
        sm.sendTextMessage(number, null, "Alta en el servicio", null, null);
    }


    @Override
    protected void onResume() {
        super.onResume();
    }
}